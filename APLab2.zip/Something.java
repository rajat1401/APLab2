import java.util.*;

class Node{
	public String name;
	public String rollno;
	public String field;
	public int dist;
	public int rank;
	
	public Node(String a, String b, String c, int dist, int rank){
		name= a;
		rollno= b;
		field= c;
		this.dist= dist;
		this.rank= rank;
	}
	
	public String getField(){
		return field;
	}
	
	public int getDist(){
		return dist;
	}	
}

public class Something {
	
	public static void Mergesortdist(Node[] array){
		sort(array);
	}
	
	public static void sort(Node[] array){
		Node[] tmp= new Node[array.length];
		mergesort(array, tmp, 0, array.length-1);
	}
	
	public static void mergesort(Node[] array, Node[] tmp, int a, int b){
		int mid= (a+b)/2;
		if(b>a){
			mergesort(array, tmp, a, mid);
			mergesort(array, tmp, mid+1, b);
			merge(array, tmp, a, mid+1, b);
		}
	}
	
	public static void merge(Node[] array, Node[] tmp, int left, int mid, int right){
		int i= left;
		int j= mid;
		int k= left;
		
		for(int a=left; a<=right; a++){
			Node nptr= new Node(array[a].name, array[a].rollno, array[a].field, array[a].dist, array[a].rank);
			tmp[a]= nptr;
		}
		
		while(i<mid && j<=right){
			if(tmp[i].dist<=tmp[j].dist){
				array[k].name= tmp[i].name;
				array[k].rollno= tmp[i].rollno;
				array[k].field= tmp[i].field;
				array[k].dist= tmp[i].dist;
				array[k].rank= tmp[i].rank;
				i++;
				k++;
			}else{
				array[k].name= tmp[j].name;
				array[k].rollno= tmp[j].rollno;
				array[k].field= tmp[j].field;
				array[k].dist= tmp[j].dist;
				array[k].rank= tmp[j].rank;
				j++;
				k++;
			}
		}
		
		while(i<mid){
			array[k].name= tmp[i].name;
			array[k].rollno= tmp[i].rollno;
			array[k].field= tmp[i].field;
			array[k].dist= tmp[i].dist;
			array[k].rank= tmp[i].rank;
			i++;
			k++;
		}
		
		while(j<=right){
			array[k].name= tmp[j].name;
			array[k].rollno= tmp[j].rollno;
			array[k].field= tmp[j].field;
			array[k].dist= tmp[j].dist;
			array[k].rank= tmp[j].rank;
			j++;
			k++;
		}
	}
	
	public static void Mergesortrank(Node[] array){
		sort2(array);
	}
	
	public static void sort2(Node[] array){
		Node[] tmp= new Node[array.length];
		mergesort2(array, tmp, 0, array.length-1);
	}
	
	public static void mergesort2(Node[] array, Node[] tmp, int a, int b){
		int mid= (a+b)/2;
		if(b>a){
			mergesort2(array, tmp, a, mid);
			mergesort2(array, tmp, mid+1, b);
			merge2(array, tmp, a, mid+1, b);
		}
	}
	
	public static void merge2(Node[] array, Node[] tmp, int left, int mid, int right){
		int i= left;
		int j= mid;
		int k= left;
		
		for(int a=left; a<=right; a++){
			Node nptr= new Node(array[a].name, array[a].rollno, array[a].field, array[a].dist, array[a].rank);
			tmp[a]= nptr;
		}
		
		while(i<mid && j<=right){
			if(tmp[i].rank<=tmp[j].rank){
				array[k].name= tmp[i].name;
				array[k].rollno= tmp[i].rollno;
				array[k].field= tmp[i].field;
				array[k].dist= tmp[i].dist;
				array[k].rank= tmp[i].rank;
				i++;
				k++;
			}else{
				array[k].name= tmp[j].name;
				array[k].rollno= tmp[j].rollno;
				array[k].field= tmp[j].field;
				array[k].dist= tmp[j].dist;
				array[k].rank= tmp[j].rank;
				j++;
				k++;
			}
		}
		
		while(i<mid){
			array[k].name= tmp[i].name;
			array[k].rollno= tmp[i].rollno;
			array[k].field= tmp[i].field;
			array[k].dist= tmp[i].dist;
			array[k].rank= tmp[i].rank;
			i++;
			k++;
		}
		
		while(j<=right){
			array[k].name= tmp[j].name;
			array[k].rollno= tmp[j].rollno;
			array[k].field= tmp[j].field;
			array[k].dist= tmp[j].dist;
			array[k].rank= tmp[j].rank;
			j++;
			k++;
		}
	}

	public static void main(String[] args){
		Scanner sc= new Scanner(System.in);
		int n=sc.nextInt();
		int m= sc.nextInt();
		Node[] array= new Node[n];
		int count1= 0;
		int count2= 0;
		for(int i=0; i<n; i++){
			Node nptr= new Node(sc.next(), sc.next(), sc.next(), sc.nextInt(), i);
			array[i]= nptr;
			if(array[i].field.equals("PG")){
				count2++;
			}else if(array[i].field.equals("PhD")){
				count1++;
			}
		}
		Mergesortdist(array);
		Node[] tmp= new Node[array.length];
		int count=0;
		for(int i=array.length-1; i>=0; i--){
			Node nptr= new Node(array[i].name, array[i].rollno, array[i].field, array[i].dist, array[i].rank);
			tmp[count]= nptr;
			count++;
		}
		/*for(int i=0; i<n; i++){
			System.out.println(tmp[i].name);
		}*/
		if(m%2==1){
			count1= Math.min(count1,  m/2 + 1);
			count2= Math.min(count2,  m/2);
		}else{
			count1= Math.min(count1,  m/2);
			count2= Math.min(count2,  m/2);
		}
		//System.out.println(count1);
		//System.out.println(count2);
		List<Node> list= new ArrayList<Node>();
		for(int i=0; i<n; i++){
			if(list.size()>=m){
				break;
			}
			if(tmp[i].field.equals("UG")){
				continue;
			}
			
			if(tmp[i].rank==100000003){
				continue;
			}
			if(count1==0 && tmp[i].field.equals("PhD")){
				continue;
			}
			if(count2==0 && tmp[i].field.equals("PG")){
				continue;
			}
			int minrank= tmp[i].rank;
			int index= i;
			for(int j=i+1; j<n; j++){
				if(tmp[j].dist!= tmp[i].dist){
					break;
				}else{
					if(tmp[j].rank<minrank){
						minrank= tmp[j].rank;
						index= j;
					}
				}
			}
			if(count1==0 && tmp[index].field.equals("PhD")){
				continue;
			}
			if(count2==0 && tmp[index].field.equals("PG")){
				continue;
			}
			list.add(tmp[index]);
			if(tmp[index].field.equals("PG")){
				count2--;
			}else if(tmp[index].field.equals("PhD")){
				count1--;
			}
			tmp[index].rank= 100000003;  
		}
		if(list.size()<m){
			for(int i=0; i<tmp.length; i++){
				if(list.size()>=m){
					break;
				}
				if(tmp[i].rank==100000003){
					continue;
				}
				if(tmp[i].field.equals("UG")){
					int minrank= tmp[i].rank;
					int index= i;
					for(int j=i+1; j<n; j++){
						if(tmp[j].dist!= tmp[i].dist){
							break;
						}else{
							if(tmp[j].rank<minrank && tmp[j].field.equals("UG")){
								minrank= tmp[j].rank;
								index= j;
							}
						}
					}
					list.add(tmp[index]);
					tmp[index].rank= 100000003;
				}
			}
		}
		Node[] array2= list.toArray(new Node[list.size()]);
		Mergesortrank(array2);
		for(int i=0; i<array2.length; i++){
			System.out.println(array2[i].name + " " +  array2[i].rollno + " " +  array2[i].field + " " +  Integer.toString(array2[i].dist));
		}
	}
}
